package de.hybris.novalnet.core.constants;

public final class NovalnetCoreConstants extends GeneratedNovalnetCoreConstants {
	
    public static final String EXTENSIONNAME = "novalnetcore";

    private NovalnetCoreConstants() {
     
    }

}
