/*
 * ----------------------------------------------------------------
 * --- WARNING: THIS FILE IS GENERATED AND WILL BE OVERWRITTEN! ---
 * --- Generated at Jul 7, 2023, 4:36:42 PM                     ---
 * ----------------------------------------------------------------
 *  
 * Copyright (c) 2023 SAP SE or an SAP affiliate company. All rights reserved.
 */
package de.hybris.novalnet.core.jalo;

import de.hybris.novalnet.core.constants.NovalnetCoreConstants;
import de.hybris.platform.jalo.GenericItem;
import de.hybris.platform.jalo.Item.AttributeMode;
import de.hybris.platform.jalo.SessionContext;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/**
 * Generated class for type {@link de.hybris.platform.jalo.GenericItem NovalnetPaymentRefInfo}.
 */
@SuppressWarnings({"deprecation","unused","cast"})
public abstract class GeneratedNovalnetPaymentRefInfo extends GenericItem
{
	/** Qualifier of the <code>NovalnetPaymentRefInfo.customerNo</code> attribute **/
	public static final String CUSTOMERNO = "customerNo";
	/** Qualifier of the <code>NovalnetPaymentRefInfo.paymentType</code> attribute **/
	public static final String PAYMENTTYPE = "paymentType";
	/** Qualifier of the <code>NovalnetPaymentRefInfo.orginalTid</code> attribute **/
	public static final String ORGINALTID = "orginalTid";
	/** Qualifier of the <code>NovalnetPaymentRefInfo.referenceTransaction</code> attribute **/
	public static final String REFERENCETRANSACTION = "referenceTransaction";
	/** Qualifier of the <code>NovalnetPaymentRefInfo.cardType</code> attribute **/
	public static final String CARDTYPE = "cardType";
	/** Qualifier of the <code>NovalnetPaymentRefInfo.cardHolder</code> attribute **/
	public static final String CARDHOLDER = "cardHolder";
	/** Qualifier of the <code>NovalnetPaymentRefInfo.maskedCardNumber</code> attribute **/
	public static final String MASKEDCARDNUMBER = "maskedCardNumber";
	/** Qualifier of the <code>NovalnetPaymentRefInfo.expiryDate</code> attribute **/
	public static final String EXPIRYDATE = "expiryDate";
	/** Qualifier of the <code>NovalnetPaymentRefInfo.accountHolder</code> attribute **/
	public static final String ACCOUNTHOLDER = "accountHolder";
	/** Qualifier of the <code>NovalnetPaymentRefInfo.maskedAccountIban</code> attribute **/
	public static final String MASKEDACCOUNTIBAN = "maskedAccountIban";
	/** Qualifier of the <code>NovalnetPaymentRefInfo.paypalTransactionID</code> attribute **/
	public static final String PAYPALTRANSACTIONID = "paypalTransactionID";
	/** Qualifier of the <code>NovalnetPaymentRefInfo.paypalEmailID</code> attribute **/
	public static final String PAYPALEMAILID = "paypalEmailID";
	/** Qualifier of the <code>NovalnetPaymentRefInfo.token</code> attribute **/
	public static final String TOKEN = "token";
	protected static final Map<String, AttributeMode> DEFAULT_INITIAL_ATTRIBUTES;
	static
	{
		final Map<String, AttributeMode> tmp = new HashMap<String, AttributeMode>();
		tmp.put(CUSTOMERNO, AttributeMode.INITIAL);
		tmp.put(PAYMENTTYPE, AttributeMode.INITIAL);
		tmp.put(ORGINALTID, AttributeMode.INITIAL);
		tmp.put(REFERENCETRANSACTION, AttributeMode.INITIAL);
		tmp.put(CARDTYPE, AttributeMode.INITIAL);
		tmp.put(CARDHOLDER, AttributeMode.INITIAL);
		tmp.put(MASKEDCARDNUMBER, AttributeMode.INITIAL);
		tmp.put(EXPIRYDATE, AttributeMode.INITIAL);
		tmp.put(ACCOUNTHOLDER, AttributeMode.INITIAL);
		tmp.put(MASKEDACCOUNTIBAN, AttributeMode.INITIAL);
		tmp.put(PAYPALTRANSACTIONID, AttributeMode.INITIAL);
		tmp.put(PAYPALEMAILID, AttributeMode.INITIAL);
		tmp.put(TOKEN, AttributeMode.INITIAL);
		DEFAULT_INITIAL_ATTRIBUTES = Collections.unmodifiableMap(tmp);
	}
	@Override
	protected Map<String, AttributeMode> getDefaultAttributeModes()
	{
		return DEFAULT_INITIAL_ATTRIBUTES;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetPaymentRefInfo.accountHolder</code> attribute.
	 * @return the accountHolder
	 */
	public String getAccountHolder(final SessionContext ctx)
	{
		return (String)getProperty( ctx, ACCOUNTHOLDER);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetPaymentRefInfo.accountHolder</code> attribute.
	 * @return the accountHolder
	 */
	public String getAccountHolder()
	{
		return getAccountHolder( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetPaymentRefInfo.accountHolder</code> attribute. 
	 * @param value the accountHolder
	 */
	public void setAccountHolder(final SessionContext ctx, final String value)
	{
		setProperty(ctx, ACCOUNTHOLDER,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetPaymentRefInfo.accountHolder</code> attribute. 
	 * @param value the accountHolder
	 */
	public void setAccountHolder(final String value)
	{
		setAccountHolder( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetPaymentRefInfo.cardHolder</code> attribute.
	 * @return the cardHolder
	 */
	public String getCardHolder(final SessionContext ctx)
	{
		return (String)getProperty( ctx, CARDHOLDER);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetPaymentRefInfo.cardHolder</code> attribute.
	 * @return the cardHolder
	 */
	public String getCardHolder()
	{
		return getCardHolder( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetPaymentRefInfo.cardHolder</code> attribute. 
	 * @param value the cardHolder
	 */
	public void setCardHolder(final SessionContext ctx, final String value)
	{
		setProperty(ctx, CARDHOLDER,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetPaymentRefInfo.cardHolder</code> attribute. 
	 * @param value the cardHolder
	 */
	public void setCardHolder(final String value)
	{
		setCardHolder( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetPaymentRefInfo.cardType</code> attribute.
	 * @return the cardType
	 */
	public String getCardType(final SessionContext ctx)
	{
		return (String)getProperty( ctx, CARDTYPE);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetPaymentRefInfo.cardType</code> attribute.
	 * @return the cardType
	 */
	public String getCardType()
	{
		return getCardType( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetPaymentRefInfo.cardType</code> attribute. 
	 * @param value the cardType
	 */
	public void setCardType(final SessionContext ctx, final String value)
	{
		setProperty(ctx, CARDTYPE,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetPaymentRefInfo.cardType</code> attribute. 
	 * @param value the cardType
	 */
	public void setCardType(final String value)
	{
		setCardType( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetPaymentRefInfo.customerNo</code> attribute.
	 * @return the customerNo
	 */
	public Long getCustomerNo(final SessionContext ctx)
	{
		return (Long)getProperty( ctx, CUSTOMERNO);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetPaymentRefInfo.customerNo</code> attribute.
	 * @return the customerNo
	 */
	public Long getCustomerNo()
	{
		return getCustomerNo( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetPaymentRefInfo.customerNo</code> attribute. 
	 * @return the customerNo
	 */
	public long getCustomerNoAsPrimitive(final SessionContext ctx)
	{
		Long value = getCustomerNo( ctx );
		return value != null ? value.longValue() : 0;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetPaymentRefInfo.customerNo</code> attribute. 
	 * @return the customerNo
	 */
	public long getCustomerNoAsPrimitive()
	{
		return getCustomerNoAsPrimitive( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetPaymentRefInfo.customerNo</code> attribute. 
	 * @param value the customerNo
	 */
	public void setCustomerNo(final SessionContext ctx, final Long value)
	{
		setProperty(ctx, CUSTOMERNO,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetPaymentRefInfo.customerNo</code> attribute. 
	 * @param value the customerNo
	 */
	public void setCustomerNo(final Long value)
	{
		setCustomerNo( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetPaymentRefInfo.customerNo</code> attribute. 
	 * @param value the customerNo
	 */
	public void setCustomerNo(final SessionContext ctx, final long value)
	{
		setCustomerNo( ctx,Long.valueOf( value ) );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetPaymentRefInfo.customerNo</code> attribute. 
	 * @param value the customerNo
	 */
	public void setCustomerNo(final long value)
	{
		setCustomerNo( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetPaymentRefInfo.expiryDate</code> attribute.
	 * @return the expiryDate
	 */
	public String getExpiryDate(final SessionContext ctx)
	{
		return (String)getProperty( ctx, EXPIRYDATE);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetPaymentRefInfo.expiryDate</code> attribute.
	 * @return the expiryDate
	 */
	public String getExpiryDate()
	{
		return getExpiryDate( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetPaymentRefInfo.expiryDate</code> attribute. 
	 * @param value the expiryDate
	 */
	public void setExpiryDate(final SessionContext ctx, final String value)
	{
		setProperty(ctx, EXPIRYDATE,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetPaymentRefInfo.expiryDate</code> attribute. 
	 * @param value the expiryDate
	 */
	public void setExpiryDate(final String value)
	{
		setExpiryDate( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetPaymentRefInfo.maskedAccountIban</code> attribute.
	 * @return the maskedAccountIban
	 */
	public String getMaskedAccountIban(final SessionContext ctx)
	{
		return (String)getProperty( ctx, MASKEDACCOUNTIBAN);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetPaymentRefInfo.maskedAccountIban</code> attribute.
	 * @return the maskedAccountIban
	 */
	public String getMaskedAccountIban()
	{
		return getMaskedAccountIban( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetPaymentRefInfo.maskedAccountIban</code> attribute. 
	 * @param value the maskedAccountIban
	 */
	public void setMaskedAccountIban(final SessionContext ctx, final String value)
	{
		setProperty(ctx, MASKEDACCOUNTIBAN,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetPaymentRefInfo.maskedAccountIban</code> attribute. 
	 * @param value the maskedAccountIban
	 */
	public void setMaskedAccountIban(final String value)
	{
		setMaskedAccountIban( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetPaymentRefInfo.maskedCardNumber</code> attribute.
	 * @return the maskedCardNumber
	 */
	public String getMaskedCardNumber(final SessionContext ctx)
	{
		return (String)getProperty( ctx, MASKEDCARDNUMBER);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetPaymentRefInfo.maskedCardNumber</code> attribute.
	 * @return the maskedCardNumber
	 */
	public String getMaskedCardNumber()
	{
		return getMaskedCardNumber( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetPaymentRefInfo.maskedCardNumber</code> attribute. 
	 * @param value the maskedCardNumber
	 */
	public void setMaskedCardNumber(final SessionContext ctx, final String value)
	{
		setProperty(ctx, MASKEDCARDNUMBER,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetPaymentRefInfo.maskedCardNumber</code> attribute. 
	 * @param value the maskedCardNumber
	 */
	public void setMaskedCardNumber(final String value)
	{
		setMaskedCardNumber( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetPaymentRefInfo.orginalTid</code> attribute.
	 * @return the orginalTid
	 */
	public Long getOrginalTid(final SessionContext ctx)
	{
		return (Long)getProperty( ctx, ORGINALTID);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetPaymentRefInfo.orginalTid</code> attribute.
	 * @return the orginalTid
	 */
	public Long getOrginalTid()
	{
		return getOrginalTid( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetPaymentRefInfo.orginalTid</code> attribute. 
	 * @return the orginalTid
	 */
	public long getOrginalTidAsPrimitive(final SessionContext ctx)
	{
		Long value = getOrginalTid( ctx );
		return value != null ? value.longValue() : 0;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetPaymentRefInfo.orginalTid</code> attribute. 
	 * @return the orginalTid
	 */
	public long getOrginalTidAsPrimitive()
	{
		return getOrginalTidAsPrimitive( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetPaymentRefInfo.orginalTid</code> attribute. 
	 * @param value the orginalTid
	 */
	public void setOrginalTid(final SessionContext ctx, final Long value)
	{
		setProperty(ctx, ORGINALTID,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetPaymentRefInfo.orginalTid</code> attribute. 
	 * @param value the orginalTid
	 */
	public void setOrginalTid(final Long value)
	{
		setOrginalTid( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetPaymentRefInfo.orginalTid</code> attribute. 
	 * @param value the orginalTid
	 */
	public void setOrginalTid(final SessionContext ctx, final long value)
	{
		setOrginalTid( ctx,Long.valueOf( value ) );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetPaymentRefInfo.orginalTid</code> attribute. 
	 * @param value the orginalTid
	 */
	public void setOrginalTid(final long value)
	{
		setOrginalTid( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetPaymentRefInfo.paymentType</code> attribute.
	 * @return the paymentType
	 */
	public String getPaymentType(final SessionContext ctx)
	{
		return (String)getProperty( ctx, PAYMENTTYPE);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetPaymentRefInfo.paymentType</code> attribute.
	 * @return the paymentType
	 */
	public String getPaymentType()
	{
		return getPaymentType( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetPaymentRefInfo.paymentType</code> attribute. 
	 * @param value the paymentType
	 */
	public void setPaymentType(final SessionContext ctx, final String value)
	{
		setProperty(ctx, PAYMENTTYPE,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetPaymentRefInfo.paymentType</code> attribute. 
	 * @param value the paymentType
	 */
	public void setPaymentType(final String value)
	{
		setPaymentType( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetPaymentRefInfo.paypalEmailID</code> attribute.
	 * @return the paypalEmailID
	 */
	public String getPaypalEmailID(final SessionContext ctx)
	{
		return (String)getProperty( ctx, PAYPALEMAILID);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetPaymentRefInfo.paypalEmailID</code> attribute.
	 * @return the paypalEmailID
	 */
	public String getPaypalEmailID()
	{
		return getPaypalEmailID( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetPaymentRefInfo.paypalEmailID</code> attribute. 
	 * @param value the paypalEmailID
	 */
	public void setPaypalEmailID(final SessionContext ctx, final String value)
	{
		setProperty(ctx, PAYPALEMAILID,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetPaymentRefInfo.paypalEmailID</code> attribute. 
	 * @param value the paypalEmailID
	 */
	public void setPaypalEmailID(final String value)
	{
		setPaypalEmailID( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetPaymentRefInfo.paypalTransactionID</code> attribute.
	 * @return the paypalTransactionID
	 */
	public String getPaypalTransactionID(final SessionContext ctx)
	{
		return (String)getProperty( ctx, PAYPALTRANSACTIONID);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetPaymentRefInfo.paypalTransactionID</code> attribute.
	 * @return the paypalTransactionID
	 */
	public String getPaypalTransactionID()
	{
		return getPaypalTransactionID( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetPaymentRefInfo.paypalTransactionID</code> attribute. 
	 * @param value the paypalTransactionID
	 */
	public void setPaypalTransactionID(final SessionContext ctx, final String value)
	{
		setProperty(ctx, PAYPALTRANSACTIONID,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetPaymentRefInfo.paypalTransactionID</code> attribute. 
	 * @param value the paypalTransactionID
	 */
	public void setPaypalTransactionID(final String value)
	{
		setPaypalTransactionID( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetPaymentRefInfo.referenceTransaction</code> attribute.
	 * @return the referenceTransaction
	 */
	public Boolean isReferenceTransaction(final SessionContext ctx)
	{
		return (Boolean)getProperty( ctx, REFERENCETRANSACTION);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetPaymentRefInfo.referenceTransaction</code> attribute.
	 * @return the referenceTransaction
	 */
	public Boolean isReferenceTransaction()
	{
		return isReferenceTransaction( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetPaymentRefInfo.referenceTransaction</code> attribute. 
	 * @return the referenceTransaction
	 */
	public boolean isReferenceTransactionAsPrimitive(final SessionContext ctx)
	{
		Boolean value = isReferenceTransaction( ctx );
		return value != null ? value.booleanValue() : false;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetPaymentRefInfo.referenceTransaction</code> attribute. 
	 * @return the referenceTransaction
	 */
	public boolean isReferenceTransactionAsPrimitive()
	{
		return isReferenceTransactionAsPrimitive( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetPaymentRefInfo.referenceTransaction</code> attribute. 
	 * @param value the referenceTransaction
	 */
	public void setReferenceTransaction(final SessionContext ctx, final Boolean value)
	{
		setProperty(ctx, REFERENCETRANSACTION,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetPaymentRefInfo.referenceTransaction</code> attribute. 
	 * @param value the referenceTransaction
	 */
	public void setReferenceTransaction(final Boolean value)
	{
		setReferenceTransaction( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetPaymentRefInfo.referenceTransaction</code> attribute. 
	 * @param value the referenceTransaction
	 */
	public void setReferenceTransaction(final SessionContext ctx, final boolean value)
	{
		setReferenceTransaction( ctx,Boolean.valueOf( value ) );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetPaymentRefInfo.referenceTransaction</code> attribute. 
	 * @param value the referenceTransaction
	 */
	public void setReferenceTransaction(final boolean value)
	{
		setReferenceTransaction( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetPaymentRefInfo.token</code> attribute.
	 * @return the token
	 */
	public String getToken(final SessionContext ctx)
	{
		return (String)getProperty( ctx, TOKEN);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetPaymentRefInfo.token</code> attribute.
	 * @return the token
	 */
	public String getToken()
	{
		return getToken( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetPaymentRefInfo.token</code> attribute. 
	 * @param value the token
	 */
	public void setToken(final SessionContext ctx, final String value)
	{
		setProperty(ctx, TOKEN,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetPaymentRefInfo.token</code> attribute. 
	 * @param value the token
	 */
	public void setToken(final String value)
	{
		setToken( getSession().getSessionContext(), value );
	}
	
}
