/*
 * ----------------------------------------------------------------
 * --- WARNING: THIS FILE IS GENERATED AND WILL BE OVERWRITTEN! ---
 * --- Generated at Jul 7, 2023, 4:36:42 PM                     ---
 * ----------------------------------------------------------------
 *  
 * Copyright (c) 2023 SAP SE or an SAP affiliate company. All rights reserved.
 */
package de.hybris.novalnet.core.jalo;

import de.hybris.novalnet.core.constants.NovalnetCoreConstants;
import de.hybris.novalnet.core.jalo.NovalnetCallbackInfo;
import de.hybris.novalnet.core.jalo.NovalnetPaymentInfo;
import de.hybris.novalnet.core.jalo.NovalnetPaymentMode;
import de.hybris.novalnet.core.jalo.NovalnetPaymentRefInfo;
import de.hybris.platform.jalo.GenericItem;
import de.hybris.platform.jalo.Item;
import de.hybris.platform.jalo.Item.AttributeMode;
import de.hybris.platform.jalo.JaloBusinessException;
import de.hybris.platform.jalo.JaloSystemException;
import de.hybris.platform.jalo.SessionContext;
import de.hybris.platform.jalo.extension.Extension;
import de.hybris.platform.jalo.type.ComposedType;
import de.hybris.platform.jalo.type.JaloGenericCreationException;
import de.hybris.platform.store.BaseStore;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/**
 * Generated class for type <code>NovalnetCoreManager</code>.
 */
@SuppressWarnings({"deprecation","unused","cast"})
public abstract class GeneratedNovalnetCoreManager extends Extension
{
	protected static final Map<String, Map<String, AttributeMode>> DEFAULT_INITIAL_ATTRIBUTES;
	static
	{
		final Map<String, Map<String, AttributeMode>> ttmp = new HashMap();
		Map<String, AttributeMode> tmp = new HashMap<String, AttributeMode>();
		tmp.put("novalnetAPIKey", AttributeMode.INITIAL);
		tmp.put("novalnetTariffId", AttributeMode.INITIAL);
		tmp.put("novalnetPaymentAccessKey", AttributeMode.INITIAL);
		tmp.put("novalnetDisplayPayments", AttributeMode.INITIAL);
		tmp.put("novalnetVendorscriptTestMode", AttributeMode.INITIAL);
		tmp.put("novalnetVendorscriptToEmailAddress", AttributeMode.INITIAL);
		ttmp.put("de.hybris.platform.store.BaseStore", Collections.unmodifiableMap(tmp));
		DEFAULT_INITIAL_ATTRIBUTES = ttmp;
	}
	@Override
	public Map<String, AttributeMode> getDefaultAttributeModes(final Class<? extends Item> itemClass)
	{
		Map<String, AttributeMode> ret = new HashMap<>();
		final Map<String, AttributeMode> attr = DEFAULT_INITIAL_ATTRIBUTES.get(itemClass.getName());
		if (attr != null)
		{
			ret.putAll(attr);
		}
		return ret;
	}
	
	public NovalnetCallbackInfo createNovalnetCallbackInfo(final SessionContext ctx, final Map attributeValues)
	{
		try
		{
			ComposedType type = getTenant().getJaloConnection().getTypeManager().getComposedType( NovalnetCoreConstants.TC.NOVALNETCALLBACKINFO );
			return (NovalnetCallbackInfo)type.newInstance( ctx, attributeValues );
		}
		catch( JaloGenericCreationException e)
		{
			final Throwable cause = e.getCause();
			throw (cause instanceof RuntimeException ?
			(RuntimeException)cause
			:
			new JaloSystemException( cause, cause.getMessage(), e.getErrorCode() ) );
		}
		catch( JaloBusinessException e )
		{
			throw new JaloSystemException( e ,"error creating NovalnetCallbackInfo : "+e.getMessage(), 0 );
		}
	}
	
	public NovalnetCallbackInfo createNovalnetCallbackInfo(final Map attributeValues)
	{
		return createNovalnetCallbackInfo( getSession().getSessionContext(), attributeValues );
	}
	
	public NovalnetPaymentInfo createNovalnetPaymentInfo(final SessionContext ctx, final Map attributeValues)
	{
		try
		{
			ComposedType type = getTenant().getJaloConnection().getTypeManager().getComposedType( NovalnetCoreConstants.TC.NOVALNETPAYMENTINFO );
			return (NovalnetPaymentInfo)type.newInstance( ctx, attributeValues );
		}
		catch( JaloGenericCreationException e)
		{
			final Throwable cause = e.getCause();
			throw (cause instanceof RuntimeException ?
			(RuntimeException)cause
			:
			new JaloSystemException( cause, cause.getMessage(), e.getErrorCode() ) );
		}
		catch( JaloBusinessException e )
		{
			throw new JaloSystemException( e ,"error creating NovalnetPaymentInfo : "+e.getMessage(), 0 );
		}
	}
	
	public NovalnetPaymentInfo createNovalnetPaymentInfo(final Map attributeValues)
	{
		return createNovalnetPaymentInfo( getSession().getSessionContext(), attributeValues );
	}
	
	public NovalnetPaymentMode createNovalnetPaymentMode(final SessionContext ctx, final Map attributeValues)
	{
		try
		{
			ComposedType type = getTenant().getJaloConnection().getTypeManager().getComposedType( NovalnetCoreConstants.TC.NOVALNETPAYMENTMODE );
			return (NovalnetPaymentMode)type.newInstance( ctx, attributeValues );
		}
		catch( JaloGenericCreationException e)
		{
			final Throwable cause = e.getCause();
			throw (cause instanceof RuntimeException ?
			(RuntimeException)cause
			:
			new JaloSystemException( cause, cause.getMessage(), e.getErrorCode() ) );
		}
		catch( JaloBusinessException e )
		{
			throw new JaloSystemException( e ,"error creating NovalnetPaymentMode : "+e.getMessage(), 0 );
		}
	}
	
	public NovalnetPaymentMode createNovalnetPaymentMode(final Map attributeValues)
	{
		return createNovalnetPaymentMode( getSession().getSessionContext(), attributeValues );
	}
	
	public NovalnetPaymentRefInfo createNovalnetPaymentRefInfo(final SessionContext ctx, final Map attributeValues)
	{
		try
		{
			ComposedType type = getTenant().getJaloConnection().getTypeManager().getComposedType( NovalnetCoreConstants.TC.NOVALNETPAYMENTREFINFO );
			return (NovalnetPaymentRefInfo)type.newInstance( ctx, attributeValues );
		}
		catch( JaloGenericCreationException e)
		{
			final Throwable cause = e.getCause();
			throw (cause instanceof RuntimeException ?
			(RuntimeException)cause
			:
			new JaloSystemException( cause, cause.getMessage(), e.getErrorCode() ) );
		}
		catch( JaloBusinessException e )
		{
			throw new JaloSystemException( e ,"error creating NovalnetPaymentRefInfo : "+e.getMessage(), 0 );
		}
	}
	
	public NovalnetPaymentRefInfo createNovalnetPaymentRefInfo(final Map attributeValues)
	{
		return createNovalnetPaymentRefInfo( getSession().getSessionContext(), attributeValues );
	}
	
	@Override
	public String getName()
	{
		return NovalnetCoreConstants.EXTENSIONNAME;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BaseStore.novalnetAPIKey</code> attribute.
	 * @return the novalnetAPIKey
	 */
	public String getNovalnetAPIKey(final SessionContext ctx, final BaseStore item)
	{
		return (String)item.getProperty( ctx, NovalnetCoreConstants.Attributes.BaseStore.NOVALNETAPIKEY);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BaseStore.novalnetAPIKey</code> attribute.
	 * @return the novalnetAPIKey
	 */
	public String getNovalnetAPIKey(final BaseStore item)
	{
		return getNovalnetAPIKey( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BaseStore.novalnetAPIKey</code> attribute. 
	 * @param value the novalnetAPIKey
	 */
	public void setNovalnetAPIKey(final SessionContext ctx, final BaseStore item, final String value)
	{
		item.setProperty(ctx, NovalnetCoreConstants.Attributes.BaseStore.NOVALNETAPIKEY,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BaseStore.novalnetAPIKey</code> attribute. 
	 * @param value the novalnetAPIKey
	 */
	public void setNovalnetAPIKey(final BaseStore item, final String value)
	{
		setNovalnetAPIKey( getSession().getSessionContext(), item, value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BaseStore.novalnetDisplayPayments</code> attribute.
	 * @return the novalnetDisplayPayments
	 */
	public Boolean isNovalnetDisplayPayments(final SessionContext ctx, final BaseStore item)
	{
		return (Boolean)item.getProperty( ctx, NovalnetCoreConstants.Attributes.BaseStore.NOVALNETDISPLAYPAYMENTS);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BaseStore.novalnetDisplayPayments</code> attribute.
	 * @return the novalnetDisplayPayments
	 */
	public Boolean isNovalnetDisplayPayments(final BaseStore item)
	{
		return isNovalnetDisplayPayments( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BaseStore.novalnetDisplayPayments</code> attribute. 
	 * @return the novalnetDisplayPayments
	 */
	public boolean isNovalnetDisplayPaymentsAsPrimitive(final SessionContext ctx, final BaseStore item)
	{
		Boolean value = isNovalnetDisplayPayments( ctx,item );
		return value != null ? value.booleanValue() : false;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BaseStore.novalnetDisplayPayments</code> attribute. 
	 * @return the novalnetDisplayPayments
	 */
	public boolean isNovalnetDisplayPaymentsAsPrimitive(final BaseStore item)
	{
		return isNovalnetDisplayPaymentsAsPrimitive( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BaseStore.novalnetDisplayPayments</code> attribute. 
	 * @param value the novalnetDisplayPayments
	 */
	public void setNovalnetDisplayPayments(final SessionContext ctx, final BaseStore item, final Boolean value)
	{
		item.setProperty(ctx, NovalnetCoreConstants.Attributes.BaseStore.NOVALNETDISPLAYPAYMENTS,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BaseStore.novalnetDisplayPayments</code> attribute. 
	 * @param value the novalnetDisplayPayments
	 */
	public void setNovalnetDisplayPayments(final BaseStore item, final Boolean value)
	{
		setNovalnetDisplayPayments( getSession().getSessionContext(), item, value );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BaseStore.novalnetDisplayPayments</code> attribute. 
	 * @param value the novalnetDisplayPayments
	 */
	public void setNovalnetDisplayPayments(final SessionContext ctx, final BaseStore item, final boolean value)
	{
		setNovalnetDisplayPayments( ctx, item, Boolean.valueOf( value ) );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BaseStore.novalnetDisplayPayments</code> attribute. 
	 * @param value the novalnetDisplayPayments
	 */
	public void setNovalnetDisplayPayments(final BaseStore item, final boolean value)
	{
		setNovalnetDisplayPayments( getSession().getSessionContext(), item, value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BaseStore.novalnetPaymentAccessKey</code> attribute.
	 * @return the novalnetPaymentAccessKey
	 */
	public String getNovalnetPaymentAccessKey(final SessionContext ctx, final BaseStore item)
	{
		return (String)item.getProperty( ctx, NovalnetCoreConstants.Attributes.BaseStore.NOVALNETPAYMENTACCESSKEY);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BaseStore.novalnetPaymentAccessKey</code> attribute.
	 * @return the novalnetPaymentAccessKey
	 */
	public String getNovalnetPaymentAccessKey(final BaseStore item)
	{
		return getNovalnetPaymentAccessKey( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BaseStore.novalnetPaymentAccessKey</code> attribute. 
	 * @param value the novalnetPaymentAccessKey
	 */
	public void setNovalnetPaymentAccessKey(final SessionContext ctx, final BaseStore item, final String value)
	{
		item.setProperty(ctx, NovalnetCoreConstants.Attributes.BaseStore.NOVALNETPAYMENTACCESSKEY,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BaseStore.novalnetPaymentAccessKey</code> attribute. 
	 * @param value the novalnetPaymentAccessKey
	 */
	public void setNovalnetPaymentAccessKey(final BaseStore item, final String value)
	{
		setNovalnetPaymentAccessKey( getSession().getSessionContext(), item, value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BaseStore.novalnetTariffId</code> attribute.
	 * @return the novalnetTariffId
	 */
	public Integer getNovalnetTariffId(final SessionContext ctx, final BaseStore item)
	{
		return (Integer)item.getProperty( ctx, NovalnetCoreConstants.Attributes.BaseStore.NOVALNETTARIFFID);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BaseStore.novalnetTariffId</code> attribute.
	 * @return the novalnetTariffId
	 */
	public Integer getNovalnetTariffId(final BaseStore item)
	{
		return getNovalnetTariffId( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BaseStore.novalnetTariffId</code> attribute. 
	 * @return the novalnetTariffId
	 */
	public int getNovalnetTariffIdAsPrimitive(final SessionContext ctx, final BaseStore item)
	{
		Integer value = getNovalnetTariffId( ctx,item );
		return value != null ? value.intValue() : 0;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BaseStore.novalnetTariffId</code> attribute. 
	 * @return the novalnetTariffId
	 */
	public int getNovalnetTariffIdAsPrimitive(final BaseStore item)
	{
		return getNovalnetTariffIdAsPrimitive( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BaseStore.novalnetTariffId</code> attribute. 
	 * @param value the novalnetTariffId
	 */
	public void setNovalnetTariffId(final SessionContext ctx, final BaseStore item, final Integer value)
	{
		item.setProperty(ctx, NovalnetCoreConstants.Attributes.BaseStore.NOVALNETTARIFFID,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BaseStore.novalnetTariffId</code> attribute. 
	 * @param value the novalnetTariffId
	 */
	public void setNovalnetTariffId(final BaseStore item, final Integer value)
	{
		setNovalnetTariffId( getSession().getSessionContext(), item, value );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BaseStore.novalnetTariffId</code> attribute. 
	 * @param value the novalnetTariffId
	 */
	public void setNovalnetTariffId(final SessionContext ctx, final BaseStore item, final int value)
	{
		setNovalnetTariffId( ctx, item, Integer.valueOf( value ) );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BaseStore.novalnetTariffId</code> attribute. 
	 * @param value the novalnetTariffId
	 */
	public void setNovalnetTariffId(final BaseStore item, final int value)
	{
		setNovalnetTariffId( getSession().getSessionContext(), item, value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BaseStore.novalnetVendorscriptTestMode</code> attribute.
	 * @return the novalnetVendorscriptTestMode
	 */
	public Boolean isNovalnetVendorscriptTestMode(final SessionContext ctx, final BaseStore item)
	{
		return (Boolean)item.getProperty( ctx, NovalnetCoreConstants.Attributes.BaseStore.NOVALNETVENDORSCRIPTTESTMODE);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BaseStore.novalnetVendorscriptTestMode</code> attribute.
	 * @return the novalnetVendorscriptTestMode
	 */
	public Boolean isNovalnetVendorscriptTestMode(final BaseStore item)
	{
		return isNovalnetVendorscriptTestMode( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BaseStore.novalnetVendorscriptTestMode</code> attribute. 
	 * @return the novalnetVendorscriptTestMode
	 */
	public boolean isNovalnetVendorscriptTestModeAsPrimitive(final SessionContext ctx, final BaseStore item)
	{
		Boolean value = isNovalnetVendorscriptTestMode( ctx,item );
		return value != null ? value.booleanValue() : false;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BaseStore.novalnetVendorscriptTestMode</code> attribute. 
	 * @return the novalnetVendorscriptTestMode
	 */
	public boolean isNovalnetVendorscriptTestModeAsPrimitive(final BaseStore item)
	{
		return isNovalnetVendorscriptTestModeAsPrimitive( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BaseStore.novalnetVendorscriptTestMode</code> attribute. 
	 * @param value the novalnetVendorscriptTestMode
	 */
	public void setNovalnetVendorscriptTestMode(final SessionContext ctx, final BaseStore item, final Boolean value)
	{
		item.setProperty(ctx, NovalnetCoreConstants.Attributes.BaseStore.NOVALNETVENDORSCRIPTTESTMODE,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BaseStore.novalnetVendorscriptTestMode</code> attribute. 
	 * @param value the novalnetVendorscriptTestMode
	 */
	public void setNovalnetVendorscriptTestMode(final BaseStore item, final Boolean value)
	{
		setNovalnetVendorscriptTestMode( getSession().getSessionContext(), item, value );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BaseStore.novalnetVendorscriptTestMode</code> attribute. 
	 * @param value the novalnetVendorscriptTestMode
	 */
	public void setNovalnetVendorscriptTestMode(final SessionContext ctx, final BaseStore item, final boolean value)
	{
		setNovalnetVendorscriptTestMode( ctx, item, Boolean.valueOf( value ) );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BaseStore.novalnetVendorscriptTestMode</code> attribute. 
	 * @param value the novalnetVendorscriptTestMode
	 */
	public void setNovalnetVendorscriptTestMode(final BaseStore item, final boolean value)
	{
		setNovalnetVendorscriptTestMode( getSession().getSessionContext(), item, value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BaseStore.novalnetVendorscriptToEmailAddress</code> attribute.
	 * @return the novalnetVendorscriptToEmailAddress
	 */
	public String getNovalnetVendorscriptToEmailAddress(final SessionContext ctx, final BaseStore item)
	{
		return (String)item.getProperty( ctx, NovalnetCoreConstants.Attributes.BaseStore.NOVALNETVENDORSCRIPTTOEMAILADDRESS);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BaseStore.novalnetVendorscriptToEmailAddress</code> attribute.
	 * @return the novalnetVendorscriptToEmailAddress
	 */
	public String getNovalnetVendorscriptToEmailAddress(final BaseStore item)
	{
		return getNovalnetVendorscriptToEmailAddress( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BaseStore.novalnetVendorscriptToEmailAddress</code> attribute. 
	 * @param value the novalnetVendorscriptToEmailAddress
	 */
	public void setNovalnetVendorscriptToEmailAddress(final SessionContext ctx, final BaseStore item, final String value)
	{
		item.setProperty(ctx, NovalnetCoreConstants.Attributes.BaseStore.NOVALNETVENDORSCRIPTTOEMAILADDRESS,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BaseStore.novalnetVendorscriptToEmailAddress</code> attribute. 
	 * @param value the novalnetVendorscriptToEmailAddress
	 */
	public void setNovalnetVendorscriptToEmailAddress(final BaseStore item, final String value)
	{
		setNovalnetVendorscriptToEmailAddress( getSession().getSessionContext(), item, value );
	}
	
}
