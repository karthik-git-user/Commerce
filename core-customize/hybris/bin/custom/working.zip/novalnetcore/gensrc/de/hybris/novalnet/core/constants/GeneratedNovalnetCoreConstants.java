/*
 * ----------------------------------------------------------------
 * --- WARNING: THIS FILE IS GENERATED AND WILL BE OVERWRITTEN! ---
 * --- Generated at Jul 7, 2023, 4:36:42 PM                     ---
 * ----------------------------------------------------------------
 *  
 * Copyright (c) 2023 SAP SE or an SAP affiliate company. All rights reserved.
 */
package de.hybris.novalnet.core.constants;

/**
 * @deprecated since ages - use constants in Model classes instead
 */
@Deprecated(since = "ages", forRemoval = false)
@SuppressWarnings({"unused","cast"})
public class GeneratedNovalnetCoreConstants
{
	public static final String EXTENSIONNAME = "novalnetcore";
	public static class TC
	{
		public static final String NOVALNETCALLBACKINFO = "NovalnetCallbackInfo".intern();
		public static final String NOVALNETPAYMENTINFO = "NovalnetPaymentInfo".intern();
		public static final String NOVALNETPAYMENTMODE = "NovalnetPaymentMode".intern();
		public static final String NOVALNETPAYMENTREFINFO = "NovalnetPaymentRefInfo".intern();
		public static final String ONHOLDACTIONTYPE = "OnholdActionType".intern();
	}
	public static class Attributes
	{
		public static class BaseStore
		{
			public static final String NOVALNETAPIKEY = "novalnetAPIKey".intern();
			public static final String NOVALNETDISPLAYPAYMENTS = "novalnetDisplayPayments".intern();
			public static final String NOVALNETPAYMENTACCESSKEY = "novalnetPaymentAccessKey".intern();
			public static final String NOVALNETTARIFFID = "novalnetTariffId".intern();
			public static final String NOVALNETVENDORSCRIPTTESTMODE = "novalnetVendorscriptTestMode".intern();
			public static final String NOVALNETVENDORSCRIPTTOEMAILADDRESS = "novalnetVendorscriptToEmailAddress".intern();
		}
	}
	public static class Enumerations
	{
		public static class OnholdActionType
		{
			public static final String AUTHORIZE = "AUTHORIZE".intern();
			public static final String CAPTURE = "CAPTURE".intern();
		}
	}
	
	protected GeneratedNovalnetCoreConstants()
	{
		// private constructor
	}
	
	
}
