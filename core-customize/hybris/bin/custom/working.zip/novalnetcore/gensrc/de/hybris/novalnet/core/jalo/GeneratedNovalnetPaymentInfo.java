/*
 * ----------------------------------------------------------------
 * --- WARNING: THIS FILE IS GENERATED AND WILL BE OVERWRITTEN! ---
 * --- Generated at Jul 7, 2023, 4:36:42 PM                     ---
 * ----------------------------------------------------------------
 *  
 * Copyright (c) 2023 SAP SE or an SAP affiliate company. All rights reserved.
 */
package de.hybris.novalnet.core.jalo;

import de.hybris.novalnet.core.constants.NovalnetCoreConstants;
import de.hybris.platform.jalo.Item.AttributeMode;
import de.hybris.platform.jalo.SessionContext;
import de.hybris.platform.jalo.order.payment.PaymentInfo;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/**
 * Generated class for type {@link de.hybris.platform.jalo.order.payment.PaymentInfo NovalnetPaymentInfo}.
 */
@SuppressWarnings({"deprecation","unused","cast"})
public abstract class GeneratedNovalnetPaymentInfo extends PaymentInfo
{
	/** Qualifier of the <code>NovalnetPaymentInfo.paymentProvider</code> attribute **/
	public static final String PAYMENTPROVIDER = "paymentProvider";
	/** Qualifier of the <code>NovalnetPaymentInfo.paymentInfo</code> attribute **/
	public static final String PAYMENTINFO = "paymentInfo";
	/** Qualifier of the <code>NovalnetPaymentInfo.orderHistoryNotes</code> attribute **/
	public static final String ORDERHISTORYNOTES = "orderHistoryNotes";
	/** Qualifier of the <code>NovalnetPaymentInfo.paymentEmailAddress</code> attribute **/
	public static final String PAYMENTEMAILADDRESS = "paymentEmailAddress";
	/** Qualifier of the <code>NovalnetPaymentInfo.paymentGatewayStatus</code> attribute **/
	public static final String PAYMENTGATEWAYSTATUS = "paymentGatewayStatus";
	protected static final Map<String, AttributeMode> DEFAULT_INITIAL_ATTRIBUTES;
	static
	{
		final Map<String, AttributeMode> tmp = new HashMap<String, AttributeMode>(PaymentInfo.DEFAULT_INITIAL_ATTRIBUTES);
		tmp.put(PAYMENTPROVIDER, AttributeMode.INITIAL);
		tmp.put(PAYMENTINFO, AttributeMode.INITIAL);
		tmp.put(ORDERHISTORYNOTES, AttributeMode.INITIAL);
		tmp.put(PAYMENTEMAILADDRESS, AttributeMode.INITIAL);
		tmp.put(PAYMENTGATEWAYSTATUS, AttributeMode.INITIAL);
		DEFAULT_INITIAL_ATTRIBUTES = Collections.unmodifiableMap(tmp);
	}
	@Override
	protected Map<String, AttributeMode> getDefaultAttributeModes()
	{
		return DEFAULT_INITIAL_ATTRIBUTES;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetPaymentInfo.orderHistoryNotes</code> attribute.
	 * @return the orderHistoryNotes
	 */
	public String getOrderHistoryNotes(final SessionContext ctx)
	{
		return (String)getProperty( ctx, ORDERHISTORYNOTES);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetPaymentInfo.orderHistoryNotes</code> attribute.
	 * @return the orderHistoryNotes
	 */
	public String getOrderHistoryNotes()
	{
		return getOrderHistoryNotes( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetPaymentInfo.orderHistoryNotes</code> attribute. 
	 * @param value the orderHistoryNotes
	 */
	public void setOrderHistoryNotes(final SessionContext ctx, final String value)
	{
		setProperty(ctx, ORDERHISTORYNOTES,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetPaymentInfo.orderHistoryNotes</code> attribute. 
	 * @param value the orderHistoryNotes
	 */
	public void setOrderHistoryNotes(final String value)
	{
		setOrderHistoryNotes( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetPaymentInfo.paymentEmailAddress</code> attribute.
	 * @return the paymentEmailAddress
	 */
	public String getPaymentEmailAddress(final SessionContext ctx)
	{
		return (String)getProperty( ctx, PAYMENTEMAILADDRESS);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetPaymentInfo.paymentEmailAddress</code> attribute.
	 * @return the paymentEmailAddress
	 */
	public String getPaymentEmailAddress()
	{
		return getPaymentEmailAddress( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetPaymentInfo.paymentEmailAddress</code> attribute. 
	 * @param value the paymentEmailAddress
	 */
	public void setPaymentEmailAddress(final SessionContext ctx, final String value)
	{
		setProperty(ctx, PAYMENTEMAILADDRESS,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetPaymentInfo.paymentEmailAddress</code> attribute. 
	 * @param value the paymentEmailAddress
	 */
	public void setPaymentEmailAddress(final String value)
	{
		setPaymentEmailAddress( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetPaymentInfo.paymentGatewayStatus</code> attribute.
	 * @return the paymentGatewayStatus
	 */
	public String getPaymentGatewayStatus(final SessionContext ctx)
	{
		return (String)getProperty( ctx, PAYMENTGATEWAYSTATUS);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetPaymentInfo.paymentGatewayStatus</code> attribute.
	 * @return the paymentGatewayStatus
	 */
	public String getPaymentGatewayStatus()
	{
		return getPaymentGatewayStatus( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetPaymentInfo.paymentGatewayStatus</code> attribute. 
	 * @param value the paymentGatewayStatus
	 */
	public void setPaymentGatewayStatus(final SessionContext ctx, final String value)
	{
		setProperty(ctx, PAYMENTGATEWAYSTATUS,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetPaymentInfo.paymentGatewayStatus</code> attribute. 
	 * @param value the paymentGatewayStatus
	 */
	public void setPaymentGatewayStatus(final String value)
	{
		setPaymentGatewayStatus( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetPaymentInfo.paymentInfo</code> attribute.
	 * @return the paymentInfo
	 */
	public String getPaymentInfo(final SessionContext ctx)
	{
		return (String)getProperty( ctx, PAYMENTINFO);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetPaymentInfo.paymentInfo</code> attribute.
	 * @return the paymentInfo
	 */
	public String getPaymentInfo()
	{
		return getPaymentInfo( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetPaymentInfo.paymentInfo</code> attribute. 
	 * @param value the paymentInfo
	 */
	public void setPaymentInfo(final SessionContext ctx, final String value)
	{
		setProperty(ctx, PAYMENTINFO,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetPaymentInfo.paymentInfo</code> attribute. 
	 * @param value the paymentInfo
	 */
	public void setPaymentInfo(final String value)
	{
		setPaymentInfo( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetPaymentInfo.paymentProvider</code> attribute.
	 * @return the paymentProvider
	 */
	public String getPaymentProvider(final SessionContext ctx)
	{
		return (String)getProperty( ctx, PAYMENTPROVIDER);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetPaymentInfo.paymentProvider</code> attribute.
	 * @return the paymentProvider
	 */
	public String getPaymentProvider()
	{
		return getPaymentProvider( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetPaymentInfo.paymentProvider</code> attribute. 
	 * @param value the paymentProvider
	 */
	public void setPaymentProvider(final SessionContext ctx, final String value)
	{
		setProperty(ctx, PAYMENTPROVIDER,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetPaymentInfo.paymentProvider</code> attribute. 
	 * @param value the paymentProvider
	 */
	public void setPaymentProvider(final String value)
	{
		setPaymentProvider( getSession().getSessionContext(), value );
	}
	
}
