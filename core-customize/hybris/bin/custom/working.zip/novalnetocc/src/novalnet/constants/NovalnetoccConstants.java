package novalnet.constants;

@SuppressWarnings({"deprecation","squid:CallToDeprecatedMethod"})
public class NovalnetoccConstants extends GeneratedNovalnetoccConstants
{
	public static final String EXTENSIONNAME = "novalnetocc";
	
	private NovalnetoccConstants()
	{
		//empty
	}
	
	
}
