/*
 * ----------------------------------------------------------------
 * --- WARNING: THIS FILE IS GENERATED AND WILL BE OVERWRITTEN! ---
 * --- Generated at Jul 7, 2023, 4:36:42 PM                     ---
 * ----------------------------------------------------------------
 */
package novalnet.constants;

/**
 * @deprecated since ages - use constants in Model classes instead
 */
@Deprecated(since = "ages", forRemoval = false)
@SuppressWarnings({"unused","cast"})
public class GeneratedNovalnetoccConstants
{
	public static final String EXTENSIONNAME = "novalnetocc";
	
	protected GeneratedNovalnetoccConstants()
	{
		// private constructor
	}
	
	
}
