package de.novalnet.constants;

@SuppressWarnings({"deprecation","squid:CallToDeprecatedMethod"})
public class NovalnetfacadesConstants extends GeneratedNovalnetfacadesConstants
{
	public static final String EXTENSIONNAME = "novalnetfacades";
	
	private NovalnetfacadesConstants()
	{
		//empty
	}
	
	
}
